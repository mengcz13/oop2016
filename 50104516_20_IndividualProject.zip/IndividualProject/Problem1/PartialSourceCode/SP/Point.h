#ifndef __SP_POINT_H__
#define __SP_POINT_H__

namespace RECTPACKING {

struct Point
{
	int x;
	int y;
};

}

#endif	//__SP_POINT_H__
